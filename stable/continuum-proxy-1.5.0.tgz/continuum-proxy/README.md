# continuum-proxy Helm Chart

Documentation for the helm chart is done in the user facing docs, at least until Continuum is open source.
