{{- define "continuum-proxy.fullname" -}}
{{- include "continuum-proxy.name" . }}-{{ .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "continuum-proxy.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "continuum-proxy.selectorLabels" -}}
{{- include "continuum-proxy.labels" . }}
{{- end }}

{{- define "continuum-proxy.labels" -}}
helm.sh/chart: {{ include "continuum-proxy.chart" . }}
app.kubernetes.io/name: {{ include "continuum-proxy.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "continuum-proxy.chart" -}}
{{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}
